import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


class Test1 {


    //from rectangle - specific rectangle
    //trans line as parameter


    @Test
    public void testChoosePointWithMinDist(){

    }

}