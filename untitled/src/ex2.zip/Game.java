import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Game {
    private static Game instance=null;
    boolean TEST=false;
    public static final int WIDTH=800;
    public static final int HEIGHT=600;
    public static final int BOUNDS_THICK=30;

    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Sleeper sleeper;

    public static Game getInstance() {
        if (Game.instance==null){
            Game.instance=new Game();
        }
        return Game.instance;
    }

    private Game(){
    }


    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    public void addSprite(Sprite s) {
        sprites.addSprite(s);
    }

    // Initialize a new game: create the Blocks and Ball (and Paddle)
    // and add them to the game.
    public void initialize() {
        this.sprites=new SpriteCollection();
        this.environment=GameEnvironment.getInstance();
        this.gui=new GUI("project2", WIDTH, HEIGHT);
        this.sleeper=new Sleeper();

        Ball ball;
        if (TEST){
            ball = new Ball(299.798604,183.536534,5,Color.black);
            ball.setVelocity(1.224745,0.707107);

        }
        else {
             ball = new Ball(WIDTH-400,HEIGHT-100,5,Color.black);
            ball.setVelocity(1,1);

        }


        Block boundLeft=new Block(0,0,BOUNDS_THICK,HEIGHT,Color.DARK_GRAY,true);
        Block boundRight=new Block(WIDTH-BOUNDS_THICK,0,BOUNDS_THICK,HEIGHT,Color.DARK_GRAY,true);
        Block boundTop=new Block(BOUNDS_THICK,0,WIDTH-2*BOUNDS_THICK,BOUNDS_THICK,Color.DARK_GRAY,true);
        Block boundBottom=new Block(BOUNDS_THICK,HEIGHT-BOUNDS_THICK,WIDTH-2*BOUNDS_THICK,BOUNDS_THICK,Color.DARK_GRAY,true);
        Paddle paddle=new Paddle(new Point(400,HEIGHT-20-BOUNDS_THICK),200,20,gui);

        boundLeft.addToGame(this);
        boundRight.addToGame(this);
        boundTop.addToGame(this);
        boundBottom.addToGame(this);
        this.addBlocksOfPattern();


        paddle.addToGame(this);



        /* Block test1 = new Block(400,400,50,50,Color.blue,true);
        Block test2= new Block(450,450,50,50,Color.blue,true);
        Block test3= new Block(450,400,50,50,Color.blue,true);

        test1.addToGame(this);
        test2.addToGame(this);
        test3.addToGame(this);
*/
        ball.addToGame(this);

    }

    public void addBlocksOfPattern(){
        int startFromRight=WIDTH-100;
        int startFromAbove=100;
        int block_width=50;
        int block_height=20;
        int blocks_in_first_row=12;
        int num_of_rows=6;
        int spaceX=0;
        int spacey=0;

        for (int row=0;row<num_of_rows;row++){
            for (int block_index=0;block_index<blocks_in_first_row-row;block_index++){
                int startX=startFromRight-(block_index+1)*(block_width+spaceX);
                int starty=startFromAbove+row*(block_height+spacey);
                Block block = new Block(startX,starty,block_width,block_height,Color.blue,true);
                block.addToGame(this);
            }
        }
    }


        // Run the game -- start the animation loop.
    public void run() {
        int framesPerSecond = 600;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing

            DrawSurface d = gui.getDrawSurface();
            this.sprites.drawAllOn(d);
            gui.show(d);
            this.sprites.notifyAllTimePassed();

            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
}