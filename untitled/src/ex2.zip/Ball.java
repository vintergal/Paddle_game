import biuoop.DrawSurface;

public class Ball implements Sprite {
    private static double minimal_distance_to_collision=1;
    // constructor
    private java.awt.Color color;
    private double r;
    private Point center;

    private Velocity velocity;
    private GameEnvironment game_environment;
    public Ball(double x, double y, double r, java.awt.Color color)
    {
        this.center=new Point(x,y);
        this.r=r;
        this.color=color;
        this.setVelocity(0,0);
        this.game_environment=GameEnvironment.getInstance();
    }
    public Ball(Point center, int r, java.awt.Color color,GameEnvironment game_environment)
    {
        this(center.getX(),center.getY(),r,color);
    }

    // accessors
    public int getIntX(){
        return this.center.getIntX();
    }
    public int getIntY(){
        return this.center.getIntY();}
    public int getSize(){
        return (int)(this.r*this.r*Math.PI);
    }
    public java.awt.Color getColor(){
        return this.color;
    }

    // draw the ball on the given DrawSurface
    public void drawOn(DrawSurface surface){
        surface.setColor(color);
        surface.drawCircle(this.getIntX(),this.getIntY(),(int)r);
    }

    @Override
    public void timePassed() {
        moveOneStep();
    }

    @Override
    public void addToGame(Game g) {
        g.addSprite(this);
    }

    public void setVelocity(Velocity v){
        this.velocity=v;
    }
    public void setVelocity(double dx, double dy){
        this.velocity=new Velocity(dx,dy);
    }
    public Velocity getVelocity(){
        return this.velocity;
    }

    public void moveOneStep() {

        Point new_center_with_epsilon = this.getVelocity().applyToPoint(this.center);
        Line trajectory=new Line(this.center,new_center_with_epsilon);

        CollisionInfo collision_info=this.game_environment.getClosestCollision(trajectory);
        if  (collision_info!=null) {
            //System.out.printf("collision on point %s\n start point %s\n start velocity %s\n\n",collision_info.collisionPoint(),this.center, this.getVelocity());
            Point collisionPoint=collision_info.collisionPoint();
            Velocity returnVelocity=collision_info.collisionObject().hit(collisionPoint,this.velocity);
            this.center=this.velocity.getEpsilon_Back(this.center);
            this.setVelocity(returnVelocity);

        }else {

            this.center = this.velocity.applyToPoint(this.center);
            if (this.center.getX()>=(Game.WIDTH-Game.BOUNDS_THICK) ||this.center.getX()<=(Game.BOUNDS_THICK) || this.center.getY()>=(Game.HEIGHT-Game.BOUNDS_THICK) ||this.center.getY()<=(Game.BOUNDS_THICK))
            {
                CollisionInfo collision_info2=this.game_environment.getClosestCollision(trajectory);

            }
        }
    }

}